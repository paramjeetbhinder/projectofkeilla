import Foundation


protocol IDisplay{
    func displayData() -> String
    
}

public protocol CaseIterable {
    associatedtype AllCases: Collection where AllCases.Element == Self
    static var allCases: AllCases { get }
}

