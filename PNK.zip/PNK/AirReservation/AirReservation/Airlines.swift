import Foundation

import Foundation

class Airlines : IDisplay {
    var airlinesID: String?
    var airlinesDescription : String?
    var airlinesType : String?
    
    
    var AirlinesID: String?{
        get{return self.airlinesID!}
        set{self.airlinesID = newValue}
    }
    
    var AirlinesDescription : String?{
        get{return self.airlinesType}
        set{self.airlinesDescription = newValue}
    }
    
    var AirlinesType: String?{
        get{return self.airlinesType}
        set{self.airlinesType = newValue}
    }
    
    
    init(){
        self.airlinesID = ""
        self.airlinesDescription = ""
        self.airlinesType = ""
        
        
    }
    
    init(airlinesID :String, airlinesDescription: String, airlinesType: String){
        
        self.airlinesID = airlinesID
        self.airlinesDescription = airlinesDescription
        self.airlinesType = airlinesType
        
        
    }
    
    
    func displayData() -> String {
        var returnData = ""
        
        returnData += "\n Airlines Id: \(self.airlinesID)"
        returnData += "\n Airlines Description: \(self.airlinesDescription ?? "")"
        returnData += "\n Airlines Type : \(self.airlinesType ?? "")"
        
        
        return returnData
    }
    
    func addAirlines(){
        print("Enter Airlines ID : ")
        self.AirlinesID = readLine()!
        print("Enter Airlines Description : ")
        self.airlinesDescription = readLine()!
        print("Enter Airlines Type : ")
        self.airlinesType = readLine()!
        
        
        
        
        
        
        
    }
}

